# Meu Planejamento — projeto Android inicial

Este projeto empacota a versão HTML 3.0 do Meu Planejamento em um aplicativo Android simples usando WebView.

## Abrir e compilar
1. Instale o Android Studio em um computador.
2. Abra a pasta `meu_planejamento_android` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
4. Conecte um Android com depuração USB ou use um emulador.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## O que já está incluído
- Versão HTML 3.0 (tema escuro/verde).
- Armazenamento local do WebView.
- JavaScript e seleção de arquivo para importar backup.
- Abertura de links HTTPS externos no navegador.

## Limitações desta primeira embalagem
- Este ambiente não possui Android SDK nem Gradle instalado; portanto, o APK ainda não foi compilado ou testado.
- Exportações por download e notificações de vencimento precisam de testes e ajustes específicos para Android.
- Não há conexão bancária Open Finance/PagBank nesta versão.
- Os dados ficam no armazenamento local do aplicativo. Faça backups regularmente.
